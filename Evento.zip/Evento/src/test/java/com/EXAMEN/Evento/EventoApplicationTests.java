package com.EXAMEN.Evento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventoApplicationTests {

	@Test
	void contextLoads() {
	}

}
